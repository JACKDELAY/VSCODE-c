#ifndef TEAADMI_H_INCLUDED
#define TEAADMI_H_INCLUDED
 
#include"teacher.h"
#include"administrator.h"
 
class TEAADMI: public TEACHER, public ADMINISTRATOR
{
private:
    static int teaadmi_sum;
public:
    TEAADMI(string a = "maomao", bool b = 1, int c = 59, string d = "0",
            string e = "计算机与信息工程学院", string f = "计算机科学与技术", string g = "教师",
            string i = "社会主义新青年");
    ~TEAADMI();
    static int get_teaadmi_sum();
    virtual void show();
    virtual void show_row();
    virtual bool change();
};
 
int TEAADMI::teaadmi_sum = 0;
 
int TEAADMI::get_teaadmi_sum()
{
    return teaadmi_sum;
}
 
TEAADMI::TEAADMI(string a, bool b, int c, string d, string e, string f, string g,  string i):
PERSON(a,b,c,d), TEACHER(a,b,c,d,e,f,g), ADMINISTRATOR(a,b,c,d,i)
{
    teaadmi_sum++;
}
 
TEAADMI::~TEAADMI()
{
    teaadmi_sum--;
}
 
void TEAADMI::show()
{
    cout << "教师及行政人员：\n";
    cout << "姓名:\t\t" << name << endl;
    cout << "姓别:\t\t";
    if(sex) cout << "男\n";
    else cout << "女\n";
    cout << "年龄:\t\t" << age << endl;
    cout << "ID:\t\t" << id << endl;
    cout << "院系:\t\t" << department << endl;
    cout << "专业:\t\t" << profession << endl;
    cout << "职务:\t\t" << title << endl;
    cout << "职称:\t\t" << position << endl;
}
 
void TEAADMI::show_row()
{
    cout << left << setw(8) << name;
    if(sex) cout << left << setw(8) << "男";
    else cout << left << setw(8) << "女";
    cout << left << setw(8) << age;
    cout << left << setw(16) << id;
    cout << left << setw(16) << department;
    cout << left << setw(16) << profession;
    cout << left << setw(16) << title;
    cout << left << setw(16) << position;
    cout << endl;
}
 
bool TEAADMI::change()
{
    cout << "姓名:\t\t" ;
    string new_name;
    cin >> new_name;
    for(unsigned int i = 0; i < new_name.length(); i++)
    {
        if(new_name[i] >= '0' && new_name[i] <= '9')
        {
            cout << "您的输入非法，请输入任意键返回\n";
            return 1;
        }
    }
    name = new_name;
 
    cout << "姓别:\t\t";
    string a;
    cin >> a;
    if(sex) man_sum--;
    else woman_sum--;
    if(a == "男") sex = 1, man_sum++;
    else sex = 0, woman_sum++;
 
    cout << "年龄:\t\t";
    cin >> age;
 
    cout << "院系:\t\t";
    cin >> department;
 
    cout << "专业:\t\t";
    cin >> profession;
 
    cout << "职务:\t\t";
    cin >> title;
    cout << "职称:\t\t";
    cin >> position;
    return 0;
}
 
#endif // TEA&ADMI_H_INCLUDED