#ifndef TEACHER_H_INCLUDED
#define TEACHER_H_INCLUDED
 
#include"person.h"
 
class TEACHER: virtual public PERSON            //虚拟继承，为教师兼管理人员的存储节省空间
{
protected:
    string department;                //学院          
    string profession;                //专业
    string title;                     //职务
    static int teacher_sum;
public:
    TEACHER(string a = "hanhan", bool b = 1, int c = 28, string d = "233",
            string e = "计算机与软件学院", string f = "软件工程", string g = "讲师");
    ~TEACHER();
 
    static int get_teacher_sum();
    virtual void show();
    virtual void show_row();
    virtual bool change();
 
    string get_department(){return department;}
    string get_profession(){return profession;}
    string get_title(){return title;}
};

int TEACHER::teacher_sum = 0;
 
int TEACHER::get_teacher_sum()
{
    return teacher_sum;
}
 
TEACHER::TEACHER(string a, bool b, int c, string d, string e, string f, string g):
PERSON(a,b,c,d), department(e), profession(f), title(g)
{
    teacher_sum++;                 //默认构造函数
}
 
TEACHER::~TEACHER()
{
    teacher_sum--;                 //默认析构函数
}
 
void TEACHER::show()
{
    cout << "教师：\n";
    cout << "姓名:\t\t" << name << endl;
    cout << "姓别:\t\t";
    if(sex) cout << "男\n";            
    else cout << "女\n";
    cout << "年龄:\t\t" << age << endl;
    cout << "ID:\t\t" << id << endl;
    cout << "院系:\t\t" << department << endl;
    cout << "专业:\t\t" << profession << endl;
    cout << "职务:\t\t" << title << endl;
}
 
void TEACHER::show_row()
{
    cout << left << setw(8) << name;
    if(sex) cout << left << setw(8) << "男";
    else cout << left << setw(8) << "女";
    cout << left << setw(8) << age;
    cout << left << setw(16) << id;
    cout << left << setw(16) << department;
    cout << left << setw(16) << profession;
    cout << left << setw(16) << title;
    cout << endl;
}
 
bool TEACHER::change()
{
    cout << "姓名:\t\t" ;
    string new_name;
    cin >> new_name;
    for(unsigned int i = 0; i < new_name.length(); i++)
    {
        if(new_name[i] >= '0' && new_name[i] <= '9')
        {
            cout << "您的输入非法，请输入任意键返回\n";
            return 1;
        }
    }
    name = new_name;
 
    cout << "姓别:\t\t";
    string a;
    cin >> a;
    if(sex) man_sum--;
    else woman_sum--;
    if(a == "男") sex = 1, man_sum++;
    else sex = 0, woman_sum++;
 
    cout << "年龄:\t\t";
    cin >> age;
 
    cout << "院系:\t\t";
    cin >> department;
 
    cout << "专业:\t\t";
    cin >> profession;
 
    cout << "职务:\t\t";
    cin >> title;
    return 0;
}
 
#endif // TEACHER_H_INCLUDED