    #include"interface.h"
     
    int main()
    {
        Information_load(); //加载信息
        interface_Manager(); //首界面
        room_delete(); //释放空间
        return 0;
    }  