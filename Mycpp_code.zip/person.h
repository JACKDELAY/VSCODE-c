#ifndef  PERSON_H_INCLUDED
#define  PERSON_H_INCLUDED
 
#include<string>
#include<iostream>
#include<iomanip>
using namespace std;
class  PERSON
{
protected:
    string name;
    bool sex;
    int age;
    string id;
    static int people_sum;
    static int man_sum;
    static int woman_sum;
public:
    PERSON( string a, bool b, int c,  string d);
    virtual ~ PERSON();
    static int get_people_sum();
    static int get_man_sum();
    static int get_woman_sum();
    virtual void show(){}
    virtual void show_row(){}
    //virtual bool change(){}
 
     string get_name(){return name;}
    bool get_sex(){return sex;}
    int get_age(){return age;}
     string get_id(){return id;}
};
 
int  PERSON::people_sum = 0;
int  PERSON::man_sum = 0;
int  PERSON::woman_sum = 0;
 
int  PERSON::get_people_sum()
{
    return people_sum;
}
 
int  PERSON::get_man_sum()
{
    return man_sum;
}
 
int  PERSON::get_woman_sum()
{
    return woman_sum;
}
 
 PERSON:: PERSON( string a, bool b, int c,  string d): name(a), sex(b), age(c), id(d)
{
    people_sum++;
    if(b) man_sum++;
    else woman_sum++;
}
 PERSON::~ PERSON()
{
    people_sum--;
    if(sex) man_sum--;
    else woman_sum--;
}
 
#endif //  PERSON_H_INCLUDED